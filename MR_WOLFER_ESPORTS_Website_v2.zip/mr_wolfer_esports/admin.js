import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth,GoogleAuthProvider,signInWithPopup,onAuthStateChanged,signOut } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore,collection,addDoc,doc,setDoc,getDoc,getDocs,query,orderBy,limit,serverTimestamp,deleteDoc } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";
import { firebaseConfig,ADMIN_EMAILS } from "./firebase-config.js";
const $=s=>document.querySelector(s), configured=firebaseConfig.apiKey&&!firebaseConfig.apiKey.startsWith("PASTE_")&&firebaseConfig.projectId!=="YOUR_PROJECT_ID";
const msg=(s,t,error=false)=>{$(s).textContent=t;$(s).className="message "+(error?"error":"success")};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
if(!configured){$("#login-btn").disabled=true;msg("#login-message","প্রথমে firebase-config.js-এ Firebase project config বসাতে হবে।",true)}
else{
 const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app),provider=new GoogleAuthProvider();
 $("#login-btn").addEventListener("click",async()=>{try{await signInWithPopup(auth,provider)}catch(e){msg("#login-message",e.message,true)}});
 $("#logout-btn").addEventListener("click",()=>signOut(auth));
 onAuthStateChanged(auth,async user=>{
  if(!user){$("#login-panel").classList.remove("hidden");$("#dashboard").classList.add("hidden");return}
  if(!ADMIN_EMAILS.map(x=>x.toLowerCase()).includes((user.email||"").toLowerCase())){msg("#login-message","এই Gmail-টি admin তালিকায় নেই। Access denied.",true);await signOut(auth);return}
  $("#login-panel").classList.add("hidden");$("#dashboard").classList.remove("hidden");$("#signed-in").textContent=`Signed in as ${user.email}`;loadManage();
  try{const s=await getDoc(doc(db,"site","live"));if(s.exists()){let d=s.data(),f=$("#live-save-form");f.elements.isLive.checked=!!d.isLive;f.elements.title.value=d.title||"";f.elements.streamUrl.value=d.streamUrl||"";f.elements.message.value=d.message||""}
   const l=await getDoc(doc(db,"site","links"));if(l.exists()){const f=$("#links-save-form");Object.entries(l.data()).forEach(([k,v])=>{if(f.elements[k])f.elements[k].value=v||""})}
  }catch(e){console.error(e)}
 });
 document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tab-panel").forEach(p=>p.classList.toggle("hidden",p.id!==b.dataset.tab))}));
 const form=(id,handler)=>$(id).addEventListener("submit",async ev=>{ev.preventDefault();try{await handler(ev.currentTarget);ev.currentTarget.reset();}catch(e){console.error(e);alert("Save failed: "+e.message)}});
 form("#event-save-form",async f=>{let d=Object.fromEntries(new FormData(f));await addDoc(collection(db,"events"),{title:d.title.trim(),date:d.date,prize:d.prize.trim(),entry:d.entry.trim(),slots:Number(d.slots)||null,registrationUrl:d.registrationUrl.trim(),description:d.description.trim(),createdAt:serverTimestamp(),createdBy:auth.currentUser.email});msg("#event-message","Tournament published successfully.");loadManage()});
 form("#live-save-form",async f=>{await setDoc(doc(db,"site","live"),{isLive:f.elements.isLive.checked,title:f.elements.title.value.trim(),streamUrl:f.elements.streamUrl.value.trim(),message:f.elements.message.value.trim(),updatedAt:serverTimestamp(),updatedBy:auth.currentUser.email});msg("#live-message","Live status saved.")});
 form("#result-save-form",async f=>{let d=Object.fromEntries(new FormData(f));await addDoc(collection(db,"results"),{title:d.title.trim(),winner:d.winner.trim(),score:d.score.trim(),date:d.date,notes:d.notes.trim(),createdAt:serverTimestamp(),createdBy:auth.currentUser.email});msg("#result-message","Result published successfully.");loadManage()});
 form("#champion-save-form",async f=>{let d=Object.fromEntries(new FormData(f));await addDoc(collection(db,"champions"),{team:d.team.trim(),tournament:d.tournament.trim(),achievement:d.achievement.trim(),imageUrl:d.imageUrl.trim(),createdAt:serverTimestamp(),createdBy:auth.currentUser.email});msg("#champion-message","Champion team published successfully.");loadManage()});
 form("#mvp-save-form",async f=>{let d=Object.fromEntries(new FormData(f));await addDoc(collection(db,"mvp"),{player:d.player.trim(),team:d.team.trim(),tournament:d.tournament.trim(),performance:d.performance.trim(),imageUrl:d.imageUrl.trim(),createdAt:serverTimestamp(),createdBy:auth.currentUser.email});msg("#mvp-message","MVP player published successfully.");loadManage()});
 form("#links-save-form",async f=>{let d=Object.fromEntries(new FormData(f));await setDoc(doc(db,"site","links"),{youtubeUrl:d.youtubeUrl.trim(),whatsappChannelUrl:d.whatsappChannelUrl.trim(),whatsappGroup1Url:d.whatsappGroup1Url.trim(),whatsappGroup2Url:d.whatsappGroup2Url.trim(),updatedAt:serverTimestamp(),updatedBy:auth.currentUser.email});msg("#links-message","Official links saved successfully.")});
 async function loadManage(){
  try{const cols=["events","results","champions","mvp"],all=await Promise.all(cols.map(c=>getDocs(query(collection(db,c),orderBy("createdAt","desc"),limit(8)))));
   const items=[];all.forEach((s,i)=>s.docs.forEach(d=>items.push({id:d.id,type:cols[i],title:d.data().title||d.data().team||d.data().player||"Untitled"})));
   $("#manage-list").innerHTML=items.length?items.map(x=>`<div class="manage-item"><div><span class="mini-tag">${esc(x.type)}</span><b>${esc(x.title)}</b><small>${esc(x.id)}</small></div><button class="btn danger" data-col="${x.type}" data-id="${esc(x.id)}">Delete</button></div>`).join(""):"No posts yet.";
   $("#manage-list").querySelectorAll("button[data-id]").forEach(b=>b.addEventListener("click",async()=>{if(!confirm("Delete this post permanently?"))return;try{await deleteDoc(doc(db,b.dataset.col,b.dataset.id));loadManage()}catch(e){alert(e.message)}}));
  }catch(e){$("#manage-list").textContent="Could not load posts: "+e.message}
 }
}