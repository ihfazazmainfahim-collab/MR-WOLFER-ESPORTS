# MR WOLFER ESPORTS — Firebase website starter

A mobile-friendly esports tournament site with public events/results/live status, champion teams, MVP list and social links and a Google sign-in admin panel.

## Important
This is a starter project. It is **not connected to your Firebase project yet**. You must add your own Firebase web config and Gmail before publishing. Do not share your password or service-account/private keys.

## Files
- `index.html` — public website
- `admin.html` — admin login and control panel
- `app.js`, `admin.js` — website logic
- `style.css` — responsive blue/black theme
- `firebase-config.js` — your Firebase web app settings
- `firestore.rules` — server-enforced admin access rules

## Setup from Android
1. Open https://console.firebase.google.com/ in Chrome and sign in with your Gmail.
2. Create a project named `mr-wolfer-esports` (or your preferred project name).
3. Add a **Web app** in Project Overview. Copy the config values into `firebase-config.js`.
4. In `firebase-config.js`, replace `YOUR_GMAIL@gmail.com` with the exact Gmail account that should administer the site.
5. Firebase Console → Authentication → Get started → Sign-in method → enable **Google**.
6. In Authentication → Settings → Authorized domains, ensure the domain where you host the site is listed. For local testing, use a local static server; opening HTML directly as `file://` will not work with ES modules.
7. Firebase Console → Firestore Database → Create database. Start in production mode.
8. Open Firestore Rules, paste `firestore.rules`, and replace `YOUR_GMAIL@gmail.com` there with the same exact Gmail. Publish the rules.
9. Host the files using Firebase Hosting (recommended) or another HTTPS static host. Firebase Hosting setup typically uses the Firebase CLI on a computer. From Android, a GitHub-based deployment service may be easier; ensure it serves all files and supports HTTPS.
10. Test the public page, then sign in at `/admin.html` using the authorized Gmail.

## Firestore data structure
- `events/{autoId}`: `title`, `date`, `prize`, `entry`, `slots`, `registrationUrl`, `description`, `createdAt`, `createdBy`
- `results/{autoId}`: `title`, `winner`, `score`, `date`, `notes`, `createdAt`, `createdBy`
- `champions/{autoId}`: `team`, `tournament`, `achievement`, `imageUrl`, `createdAt`, `createdBy`
- `mvp/{autoId}`: `player`, `team`, `tournament`, `performance`, `imageUrl`, `createdAt`, `createdBy`
- `site/live`: `isLive`, `title`, `streamUrl`, `message`, `updatedAt`, `updatedBy`
- `site/links`: `youtubeUrl`, `whatsappChannelUrl`, `whatsappGroup1Url`, `whatsappGroup2Url`, `updatedAt`, `updatedBy`

## Security notes
- The email allowlist in `firebase-config.js` only hides the admin UI for other users. **The real protection is Firestore Security Rules**, which must contain your exact Gmail.
- Never use public write rules such as `allow read, write: if true`.
- Do not publish Firebase service-account JSON files or private server credentials.
- Firebase web API keys are intended to identify your web app; data access must be protected by Security Rules and Firebase Authentication.
- For production, add Firebase App Check, input moderation, backups, and tighter field validation.
- Only publish stream links and tournament data you are allowed to share.

## Branding
The logo is currently a temporary MW monogram because the previous MR WOLFER logo image was not attached to this project. Replace the `MW` logo element in the HTML with your own transparent PNG once available.


## Added in this version
- Public dashboard summary cards
- Champion Teams and MVP List sections
- Admin forms to add champion teams and MVP players
- Admin form for YouTube, WhatsApp Channel and two WhatsApp Group links
- Updated Firestore rules for `champions`, `mvp`, and `site/links`
