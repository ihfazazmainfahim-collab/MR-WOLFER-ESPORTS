// 1) Firebase Console > Project settings > Your apps > Web app.
// 2) Copy your project's config values below. Never put service-account keys here.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_APP_ID"
};

// Add the exact Google account email(s) that may manage the site.
// This list is used by the admin interface; Firestore Rules must also enforce admin access.
export const ADMIN_EMAILS = [
  "YOUR_GMAIL@gmail.com"
];