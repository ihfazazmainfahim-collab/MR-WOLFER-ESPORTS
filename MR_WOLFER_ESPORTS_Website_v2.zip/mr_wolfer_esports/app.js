import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getFirestore, collection, query, orderBy, limit, getDocs, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";
const $=s=>document.querySelector(s); $("#year").textContent=new Date().getFullYear();
const configured=firebaseConfig.apiKey&&!firebaseConfig.apiKey.startsWith("PASTE_")&&firebaseConfig.projectId!=="YOUR_PROJECT_ID";
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeUrl=v=>{try{const u=new URL(v);return ["https:","http:"].includes(u.protocol)?u.href:""}catch{return ""}};
function empty(id,text){$(id).innerHTML=`<div class="empty">${text}</div>`}
if(!configured){
 $("#live-status").textContent="SETUP REQUIRED"; ["#events-grid","#results-grid","#champions-grid","#mvp-grid"].forEach(id=>empty(id,"Connect Firebase to load published information."));
 $("#live-card").innerHTML='<div class="live-mark muted-mark">MW</div><div><h3>Website preview mode</h3><p>Firebase config is not added yet. Follow README.md to connect your project.</p></div>';
 $("#dash-events").textContent=$("#dash-champions").textContent=$("#dash-mvp").textContent="0";$("#dash-live").textContent="SETUP";
}else{
 try{
  const app=initializeApp(firebaseConfig),db=getFirestore(app);
  const [es,rs,cs,ms,ls,ss]=await Promise.all([
   getDocs(query(collection(db,"events"),orderBy("date","asc"),limit(30))),
   getDocs(query(collection(db,"results"),orderBy("createdAt","desc"),limit(8))),
   getDocs(query(collection(db,"champions"),orderBy("createdAt","desc"),limit(12))),
   getDocs(query(collection(db,"mvp"),orderBy("createdAt","desc"),limit(12))),
   getDoc(doc(db,"site","live")),getDoc(doc(db,"site","links"))
  ]);
  const now=new Date(),events=es.docs.map(d=>({id:d.id,...d.data()})).filter(e=>!e.date||new Date(e.date)>=now);
  const results=rs.docs.map(d=>d.data()), champs=cs.docs.map(d=>d.data()), mvps=ms.docs.map(d=>d.data());
  $("#dash-events").textContent=events.length;$("#dash-champions").textContent=champs.length;$("#dash-mvp").textContent=mvps.length;
  const live=ls.exists()?ls.data():{};$("#dash-live").textContent=live.isLive?"LIVE":"OFFLINE";
  $("#live-status").textContent=live.isLive?"● LIVE NOW":"● OFFLINE";$("#live-status").classList.toggle("is-live",!!live.isLive);
  $("#live-card").innerHTML=`<div class="${live.isLive?"live-mark":"live-mark muted-mark"}">${live.isLive?"LIVE":"MW"}</div><div><h3>${esc(live.title||(live.isLive?"Live match in progress":"No live match right now"))}</h3><p>${esc(live.message||(live.isLive?"Follow the match using the stream link.":"Check back for the next tournament broadcast."))}</p></div>${safeUrl(live.streamUrl)?`<a class="live-arrow" href="${esc(safeUrl(live.streamUrl))}" target="_blank" rel="noopener noreferrer">↗</a>`:""}`;
  $("#events-grid").innerHTML=events.length?events.map(e=>`<article class="event-card"><div class="card-top"><span class="mini-tag">UPCOMING</span><span class="card-symbol">✦</span></div><h3>${esc(e.title)}</h3><p>${esc(e.description||"Tournament details will be announced.")}</p><div class="meta-row"><span>PRIZE POOL</span><b>${esc(e.prize||"TBA")}</b></div><div class="meta-row"><span>ENTRY FEE</span><b>${esc(e.entry||"TBA")}</b></div><div class="meta-row"><span>SLOTS</span><b>${esc(e.slots||"TBA")}</b></div><div class="card-footer"><span>${esc(e.date?new Date(e.date).toLocaleString():"Date TBA")}</span>${safeUrl(e.registrationUrl)?`<a href="${esc(safeUrl(e.registrationUrl))}" target="_blank" rel="noopener noreferrer">Register ↗</a>`:""}</div></article>`).join(""):"<div class='empty'>No upcoming tournaments published yet.</div>";
  $("#results-grid").innerHTML=results.length?results.map(r=>`<article class="result-card"><div class="result-icon">🏆</div><div><span class="mini-tag">FINAL RESULT</span><h3>${esc(r.title)}</h3><p>Champion: <b>${esc(r.winner)}</b></p><small>${esc(r.score||"")}${r.date?" · "+esc(r.date):""}</small>${r.notes?`<p>${esc(r.notes)}</p>`:""}</div></article>`).join(""):"<div class='empty'>No results published yet.</div>";
  $("#champions-grid").innerHTML=champs.length?champs.map(c=>`<article class="event-card honor-card">${safeUrl(c.imageUrl)?`<img class="team-image" src="${esc(safeUrl(c.imageUrl))}" alt="Team logo" loading="lazy">`:`<div class="honor-emblem">🏆</div>`}<span class="mini-tag">CHAMPION TEAM</span><h3>${esc(c.team)}</h3><p>${esc(c.tournament||"Tournament winner")}</p><div class="meta-row"><span>ACHIEVEMENT</span><b>${esc(c.achievement||"Champion")}</b></div></article>`).join(""):"<div class='empty'>Champion teams will be added by the admin.</div>";
  $("#mvp-grid").innerHTML=mvps.length?mvps.map(m=>`<article class="event-card mvp-card">${safeUrl(m.imageUrl)?`<img class="player-image" src="${esc(safeUrl(m.imageUrl))}" alt="MVP player" loading="lazy">`:`<div class="player-placeholder">MVP</div>`}<span class="mini-tag">MOST VALUABLE PLAYER</span><h3>${esc(m.player)}</h3><p>${esc(m.team||"Team not specified")}</p><div class="meta-row"><span>TOURNAMENT</span><b>${esc(m.tournament||"—")}</b></div><div class="meta-row"><span>PERFORMANCE</span><b>${esc(m.performance||"MVP")}</b></div></article>`).join(""):"<div class='empty'>MVP players will be added by the admin.</div>";
  const links=ss.exists()?ss.data():{};let visible=0;
  document.querySelectorAll("[data-link]").forEach(a=>{const url=safeUrl(links[a.dataset.link]);if(url){a.href=url;a.target="_blank";a.rel="noopener noreferrer";a.classList.remove("disabled-link");visible++}else{a.classList.add("disabled-link");a.removeAttribute("href");}});
  $("#social-note").textContent=visible?"Follow MR WOLFER ESPORTS through the official links above.":"Official links will be added by the admin.";
 }catch(e){console.error(e);$("#live-status").textContent="CONNECTION ISSUE";["#events-grid","#results-grid","#champions-grid","#mvp-grid"].forEach(id=>empty(id,"Could not load data. Check Firebase setup and Firestore rules."));}
}